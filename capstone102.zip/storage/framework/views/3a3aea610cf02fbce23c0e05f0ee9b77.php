

<?php $__env->startSection('content'); ?>
<div class="flex justify-center items-center min-h-screen">
    <div class="bg-white p-6 rounded-lg shadow-md w-full max-w-md">
        <h2 class="text-xl font-bold mb-4">Enter Your Email</h2>
        <form action="<?php echo e(route('otp.send')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="mb-4">
                <label>Email Address</label>
                <input type="email" name="email" class="w-full border rounded p-2" required>
            </div>
            <button type="submit" class="bg-blue-600 text-white w-full py-2 rounded">Send OTP</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default-layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\capstone102\resources\views/auth/otp-email.blade.php ENDPATH**/ ?>