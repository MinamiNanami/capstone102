

<?php $__env->startSection('content'); ?>
<div class="flex items-center justify-center min-h-screen">
    <div class="bg-white p-6 rounded-lg shadow-md w-full max-w-md">
        <h2 class="text-2xl font-bold mb-4">Enter OTP</h2>

        <?php if(session('success')): ?>
            <div class="text-green-600 mb-2"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <?php $__errorArgs = ['otp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-red-600 mb-2"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <form method="POST" action="<?php echo e(route('otp.verify')); ?>">
            <?php echo csrf_field(); ?>
            <div class="mb-4">
                <label for="otp" class="block text-gray-700">One-Time Password</label>
                <input type="text" name="otp" id="otp" class="w-full p-2 border rounded" maxlength="6" required>
            </div>
            <button type="submit" class="w-full bg-blue-600 text-white py-2 rounded">Verify</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default-layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\capstone102\resources\views/auth/otp-verify.blade.php ENDPATH**/ ?>